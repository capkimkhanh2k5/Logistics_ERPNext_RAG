# TT85/2026/TT-BTC — Bản bóc tách hoàn chỉnh cho Knowledge Base

- Source: `ThongTu_85-2026_TT-BTC.docx`
- SHA-256: `a69d7f198bd194887108b7912b2375fa9d55b3b251e9b473c658c88d93d4bd8f`
- Số Điều: **17**
- Phụ lục biểu mẫu: **5 mẫu**
- Hiệu lực theo nội dung nguồn: **15/09/2026**
- Phạm vi sử dụng trong AI: **toàn bộ hệ thống HS**

## 1. Tiền đề/căn cứ ban hành

| BỘ TÀI CHÍNH | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAMĐộc lập - Tự do - Hạnh phúc |
| --- | --- |
| Số: 85/2026/TT-BTC | Hà Nội, ngày 30 tháng 6 năm 2026 |
THÔNG TƯ

Quy định về phân loại hàng hoá, phân tích để phân loại hàng hoá xuất khẩu, nhập khẩu

Căn cứ Luật Hải quan số 54/2014/QH13;

Căn cứ Luật Thuế xuất khẩu, thuế nhập khẩu số 107/2016/QH13;

Căn cứ Luật sửa đổi, bổ sung một số Điều của Luật Đấu thầu, Luật Đầu tư theo phương thức đối tác công tư, Luật Hải quan, Luật Thuế Giá trị gia tăng, Luật Thuế xuất nhập khẩu, Luật Đầu tư, Luật Đầu tư công, Luật Quản lý, sử dụng tài sản công số 90/2025/QH15;

Căn cứ Luật Thương mại số 36/2005/QH11;

Căn cứ Luật Chất lượng sản phẩm, hàng hóa số 55/2007/QH12 được sửa đổi, bổ sung bởi Luật số 35/2018/QH14 và Luật số 78/2025/QH15;

Căn cứ Nghị định số 08/2015/NĐ-CP quy định chi tiết và biện pháp thi hành Luật Hải quan về thủ tục hải quan, kiểm tra, giám sát, kiểm soát hải quan được sửa đổi, bổ sung bởi Nghị định số 167/2025/NĐ-CP;

Căn cứ Nghị định số 134/2016/NĐ-CP quy định chi tiết thi hành một số điều của Luật Thuế xuất khẩu, thuế nhập khẩu được sửa đổi, bổ sung bởi Nghị định số 18/2021/NĐ-CP và Nghị định số 182/2025/NĐ-CP;

Căn cứ Nghị định số 20/2006/NĐ-CP quy định chi tiết Luật Thương mại về kinh doanh dịch vụ giám định thương mại được sửa đổi, bổ sung bởi Nghị định số 125/2014/NĐ-CP;

Căn cứ Nghị định số 69/2018/NĐ-CP của Chính phủ quy định chi tiết một số điều của Luật Quản lý ngoại thương;

Căn cứ Nghị định số 29/2025/NĐ-CP quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Tài chính được sửa đổi, bổ sung bởi Nghị định số 166/2025/NĐ-CP;

Thực hiện Nghị định thư quy định việc thực hiện Danh mục thuế quan hài hòa ASEAN;

Theo đề nghị của Cục trưởng Cục Hải quan;

Bộ trưởng Bộ Tài chính ban hành Thông tư quy định về phân loại hàng hóa, phân tích để phân loại hàng hóa xuất khẩu, nhập khẩu.


## 2. Toàn văn 17 Điều đã chuẩn hóa cấu trúc

### Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. 1. Thông tư này quy định việc phân loại hàng hóa, phân tích để phân loại hàng hóa xuất khẩu, nhập khẩu, xây dựng và sử dụng cơ sở dữ liệu về Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam.

2. Người khai hải quan, cơ quan hải quan, công chức hải quan và các tổ chức, cá nhân khác khi thực hiện các công việc có liên quan đến phân loại hàng hóa, phân tích để phân loại hàng hoá xuất khẩu, nhập khẩu, xây dựng và sử dụng cơ sở dữ liệu về Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam là đối tượng thực hiện Thông tư này.

### Điều 2. Giải thích từ ngữ

Trong Thông tư này, các từ ngữ dưới đây được hiểu như sau:

1. Công ước Quốc tế về Hệ thống hài hòa mô tả và mã hóa hàng hóa (International Convention on the Harmonized Commodity Description and Coding System) (gọi tắt là Công ước HS) là Công ước do Hội đồng hợp tác Hải quan, nay gọi là Tổ chức Hải quan Thế giới (WCO) thông qua ngày 14 tháng 6 năm 1983 tại Bruxelles, Vương quốc Bỉ về “Hệ thống hài hòa mô tả và mã hóa hàng hóa”.

2. Hệ thống hài hòa mô tả và mã hóa hàng hóa của Tổ chức Hải quan Thế giới (sau đây gọi tắt là Hệ thống HS), là hệ thống bao gồm danh mục những nhóm hàng, phân nhóm hàng cùng các mã số có liên quan, chú giải pháp lý Phần, Chương, Phân nhóm và các Quy tắc tổng quát.

3. Danh mục hài hòa mô tả và mã hóa hàng hóa của Tổ chức Hải quan Thế giới (sau đây gọi tắt là Danh mục HS) là danh mục những nhóm hàng (mã 4 chữ số), phân nhóm hàng (mã 6 chữ số), chú giải pháp lý Phần, Chương, Phân nhóm được sắp xếp một cách có hệ thống ứng với tên, mô tả và mã số hàng hóa.

4. Quy tắc tổng quát là các quy tắc chung để giải thích Hệ thống HS nhằm phân loại hàng hóa vào một nhóm, phân nhóm nhất định.

5. Chú giải pháp lý là những nội dung giải thích các phần, chương và phân nhóm được gắn kèm ở đầu các Phần, Chương của Danh mục HS.

6. Danh mục thuế quan hài hòa ASEAN (sau đây gọi tắt là Danh mục AHTN) là danh mục hàng hóa của các nước ASEAN, được xây dựng trên cơ sở Hệ thống HS của Tổ chức Hải quan Thế giới.

7. Chú giải chi tiết Danh mục HS là những giải thích tổng quát và chi tiết về phạm vi, nội dung của các Phần, Chương, Nhóm, Phân nhóm của Danh mục HS.

8. Chú giải bổ sung Danh mục AHTN (SEN) là phụ lục của Nghị định thư về việc thực hiện Danh mục AHTN để giải thích phạm vi, nội dung các phân nhóm trong Danh mục do các nước ASEAN xây dựng.

9. Tuyển tập các ý kiến phân loại của WCO là tài liệu tập hợp các Quyết định phân loại hàng hóa đã được Ủy ban HS của Tổ chức Hải quan thế giới thông qua.

10. Phân tích hàng hóa là việc cơ quan kiểm định hải quan sử dụng máy móc, thiết bị kỹ thuật để phân tích mẫu hàng hóa xuất khẩu, nhập khẩu:

a) Xác định thành phần, cấu tạo, tính chất lý, hóa, công dụng làm cơ sở phân loại hàng hóa theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam;

b) Kiểm tra, đánh giá tiêu chí kỹ thuật của hàng hóa, xác định tiêu chuẩn chất lượng hàng hóa theo tiêu chuẩn quốc gia, quy chuẩn kỹ thuật do các cơ quan quản lý nhà nước ban hành hoặc tiêu chuẩn quốc tế để đơn vị yêu cầu phân tích làm cơ sở quyết định thông quan hàng hoá.

11. Giám định, thử nghiệm hàng hóa là việc cơ quan hải quan trưng cầu giám định, thử nghiệm tại các tổ chức giám định, thử nghiệm theo quy định của pháp luật để xác định cấu tạo, thành phần, tính chất lý, hóa, công dụng của hàng hóa theo yêu cầu của cơ quan hải quan để xác định tên hàng, mã số hàng hóa xuất khẩu, nhập khẩu.

### Điều 3. Phân tích để phân loại hàng hóa

1. Trường hợp cơ quan hải quan không đủ cơ sở để xác định tính chính xác việc phân loại hàng hóa của người khai hải quan thì thực hiện phân tích, giám định hàng hóa theo quy định tại khoản 5 Điều 29 Nghị định số 08/2015/NĐ-CP quy định chi tiết và biện pháp thi hành Luật Hải quan về thủ tục hải quan, kiểm tra, giám sát, kiểm soát hải quan được sửa đổi, bổ sung bởi khoản 15 Điều 1 Nghị định số 167/2025/NĐ-CP.

2. Trường hợp cơ quan kiểm định hải quan chưa đủ điều kiện thực hiện phân tích một số chỉ tiêu kỹ thuật hoặc cần phân tích kiểm chứng thì sử dụng dịch vụ giám định, thử nghiệm của các tổ chức giám định, thử nghiệm theo quy định của pháp luật để làm cơ sở thực hiện.

3. Để phân loại hàng hóa, người khai hải quan có thể sử dụng các dịch vụ giám định hàng hóa của các tổ chức giám định theo quy định của pháp luật hoặc cơ sở dữ liệu về Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam để xác định các thông tin về thành phần, tính chất lý, hóa, tính năng, công dụng của hàng hóa xuất khẩu, nhập khẩu và chịu trách nhiệm về tính chính xác, hợp pháp của tài liệu cung cấp.

### Điều 4. Nguyên tắc phân loại hàng hóa

1. Một mặt hàng có một mã số duy nhất theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam.

2. Khi phân loại hàng hóa xuất khẩu, nhập khẩu, phải tuân thủ:

a) Điều 26 Luật Hải quan số 54/2014/QH13; Điều 16 Nghị định số 08/2015/NĐ-CP;

b) Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam;

c) Biểu thuế xuất khẩu, Biểu thuế nhập khẩu;

d) 6 (sáu) quy tắc tổng quát giải thích việc phân loại hàng hóa theo Hệ thống hài hoà mô tả và mã hoá hàng hóa;

e) Các nội dung hướng dẫn tại Thông tư này.

### Điều 5. Sử dụng kết quả phân loại

1. Kết quả phân loại hàng hóa được sử dụng để áp dụng chính sách quản lý hàng hóa trên cơ sở thực hiện quy định về điều kiện, thủ tục, hồ sơ áp dụng tại Danh mục hàng hóa cấm xuất khẩu, tạm ngừng xuất khẩu; Danh mục hàng hóa cấm nhập khẩu, tạm ngừng nhập khẩu; Danh mục hàng hóa xuất khẩu, nhập khẩu theo giấy phép của cơ quan nhà nước có thẩm quyền; Danh mục hàng hóa thuộc đối tượng kiểm tra chuyên ngành có hiệu lực tại thời điểm đăng ký tờ khai.

2. Kết quả phân loại hàng hóa được sử dụng để áp dụng mức thuế đối với một mặt hàng trên cơ sở thực hiện quy định tại các Biểu thuế áp dụng đối với hàng hóa xuất khẩu, nhập khẩu có hiệu lực tại thời điểm đăng ký tờ khai và điều kiện, thủ tục, hồ sơ để được áp dụng mức thuế quy định tại các văn bản quy phạm pháp luật về thuế đối với hàng hóa xuất khẩu, nhập khẩu.

### Điều 6. Phân loại, áp dụng mức thuế đối với một số trường hợp đặc biệt

1. Trường hợp thực hiện phân loại hàng hóa theo quy định tại Điều 4 Thông tư này nhưng chưa xác định được mã số duy nhất theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam thì sử dụng các tài liệu sau:

a) Chú giải chi tiết Danh mục HS;

b) Tuyển tập ý kiến phân loại của WCO;

c) Chú giải bổ sung Danh mục AHTN;

d) Cơ sở dữ liệu về Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam.

2. Trường hợp có sự khác biệt về mô tả hàng hóa tại Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam và mô tả hàng hóa theo Danh mục HS, Danh mục AHTN thì áp dụng trực tiếp mô tả hàng hóa theo Danh mục HS, Danh mục AHTN để phân loại và hướng dẫn phân loại theo nguyên tắc áp dụng quy định của Điều ước quốc tế mà Việt Nam là thành viên.

3. Trường hợp thực hiện quy định tại Điều 4 và khoản 1 Điều 6 Thông tư này chưa đủ cơ sở để xác định tên gọi, mô tả hàng hóa theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam thì được sử dụng các tiêu chí, tiêu chuẩn, quy chuẩn do cơ quan, tổ chức, đơn vị có thẩm quyền ban hành theo quy định để làm cơ sở xác định tên gọi, mô tả hàng hóa, mã số theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam.

4. Trường hợp hàng hoá có mã số tại Danh mục hàng hoá quản lý chuyên ngành khác biệt với mã số xác định theo Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam thì thực hiện theo Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam và pháp luật về hải quan.

5. Trường hợp mặt hàng phức tạp, khó phân loại, Cục trưởng Cục Hải quan trên cơ sở ý kiến của Bộ, cơ quan ngang Bộ quản lý chuyên ngành hoặc Ủy ban HS thuộc Tổ chức Hải quan thế giới hoặc Nhóm kỹ thuật về phân loại hàng hoá của ASEAN ban hành văn bản sửa đổi, hướng dẫn phân loại, làm ảnh hưởng tới quá trình khai báo hải quan về mã số, mức thuế và hiệu quả của hoạt động sản xuất kinh doanh của người khai hải quan, người nộp thuế thì thực hiện phân loại hàng hóa kể từ ngày văn bản sửa đổi, hướng dẫn phân loại được ban hành.

### Điều 7. Phân loại máy liên hợp hoặc tổ hợp máy thuộc các Chương 84, Chương 85 và Chương 90

Hàng hóa là máy liên hợp (gồm hai hay nhiều máy) hoặc tổ hợp máy thuộc các Chương 84, Chương 85 và Chương 90 của Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam được nhập khẩu từ một nguồn hay nhiều nguồn cung cấp, về nhiều chuyến, làm thủ tục tại một hay nhiều đơn vị hải quan khác nhau thì người khai hải quan được lựa chọn phân loại theo từng máy móc, thiết bị hoặc theo quy định tại Chú giải pháp lý 3, 4, 5 Phần XVI của Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam.

Trường hợp lựa chọn phân loại theo quy định tại Chú giải pháp lý 3, 4, 5 Phần XVI của Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam thì thực hiện theo hướng dẫn tại Điều 9 dưới đây.

### Điều 8. Phân loại máy móc, thiết bị ở dạng chưa lắp ráp hoặc tháo rời

Hàng hóa là máy móc, thiết bị ở dạng chưa lắp ráp hoặc tháo rời thường do yêu cầu đóng gói, bảo quản hoặc vận chuyển thực hiện phân loại theo quy tắc 2a của 6 (sáu) quy tắc tổng quát giải thích Hệ thống HS.

Trường hợp hàng hóa được nhập khẩu từ một nguồn hay nhiều nguồn cung cấp, về nhiều chuyến, làm thủ tục tại một hay nhiều đơn vị hải quan khác nhau thì người khai hải quan, cơ quan hải quan thực hiện theo hướng dẫn tại Điều 9 dưới đây.

### Điều 9. Hồ sơ, thủ tục đối với hàng hóa phân loại theo Điều 7, Điều 8

1. Hồ sơ đăng ký Danh mục:

a) Danh mục máy móc, thiết bị; các chi tiết, linh kiện rời của máy móc, thiết bị (theo mẫu số 01/ĐKDMTB/2025 tại Phụ lục V ban hành kèm theo Thông tư số 121/2025/TT-BTC sửa đổi, bổ sung một số điều của các Thông tư quy định về thủ tục hải quan, kiểm tra, giám sát hải quan, thuế xuất khẩu, thuế nhập khẩu và quản lý thuế đối với hàng hoá xuất khẩu, nhập khẩu);

b) Phiếu theo dõi trừ lùi (theo mẫu số 02/PTDTL-DMTB/2025 tại Phụ lục V ban hành kèm theo Thông tư số 121/2025/TT-BTC).

2. Thủ tục thực hiện đối với người khai hải quan:

a) Người khai hải quan thực hiện khai các chỉ tiêu thông tin thông qua Hệ thống xử lý dữ liệu điện tử hải quan, trường hợp Hệ thống chưa có chức năng tiếp nhận chỉ tiêu thông tin thì nộp bản scan có xác nhận bằng chữ ký số các chứng từ thuộc hồ sơ hoặc gửi hồ sơ trực tiếp đến cơ quan hải quan.

b) Người khai hải quan nộp hồ sơ đăng ký Danh mục quy định tại khoản 1 Điều này trước thời điểm đăng ký tờ khai hải quan nhập khẩu lô hàng đầu tiên tại cơ quan hải quan nơi thuận tiện nhất.

c) Trường hợp Danh mục đã đăng ký nhưng người khai hải quan cần sửa đổi, bổ sung thì người khai hải quan nộp Danh mục và Phiếu theo dõi trừ lùi sửa đổi, bổ sung cho cơ quan hải quan nơi người khai hải quan đăng ký Danh mục trước thời điểm đăng ký tờ khai hải quan nhập khẩu lô hàng đầu tiên hoặc trước thời điểm đăng ký tờ khai hải quan nhập khẩu lô hàng tiếp theo có sửa đổi, bổ sung Danh mục.

d) Trường hợp người khai hải quan mất Danh mục thì có văn bản đề nghị cơ quan hải quan nơi đăng ký Danh mục cấp lại Danh mục.

Trường hợp mất Phiếu theo dõi trừ lùi thì người khai hải quan lập Phiếu theo dõi trừ lùi mới trong đó tự kê khai và chịu trách nhiệm trước pháp luật về số tờ khai và số lượng máy móc, thiết bị hoặc chi tiết, linh kiện trong Danh mục đã nhập khẩu gửi cơ quan hải quan nơi làm thủ tục nhập khẩu lô hàng tiếp theo.

3. Thủ tục thực hiện đối với cơ quan hải quan:

a) Tiếp nhận hồ sơ đăng ký Danh mục

a.1) Cơ quan hải quan thực hiện tiếp nhận và kiểm tra hồ sơ đăng ký Danh mục hoặc Danh mục sửa đổi, bổ sung do người khai hải quan nộp theo khoản 1, khoản 2 Điều này. Trường hợp hồ sơ đăng ký Danh mục hoặc hồ sơ đăng ký sửa đổi, bổ sung Danh mục đúng quy định thì trong thời hạn không quá 03 ngày làm việc, cơ quan hải quan xác nhận Danh mục và Phiếu theo dõi trừ lùi, lưu 01 bản chính Danh mục, giao cho người khai hải quan 01 bản chính Danh mục kèm 01 bản chính Phiếu theo dõi trừ lùi.

a.2) Trường hợp người khai hải quan mất Danh mục hoặc Phiếu theo dõi trừ lùi.

Trường hợp mất Danh mục, cơ quan hải quan nơi người khai hải quan đăng ký Danh mục thực hiện kiểm tra và cấp lại Danh mục trong thời hạn không quá 03 ngày làm việc kể từ ngày nhận được văn bản đề nghị theo điểm d khoản 2 Điều này.

Trường hợp mất Phiếu theo dõi trừ lùi, cơ quan hải quan nơi làm thủ tục nhập khẩu lô hàng tiếp theo tiếp nhận và kiểm tra các nội dung tự kê khai trên Phiếu theo dõi trừ lùi mới do người khai hải quan lập, đối chiếu với các thông tin trên hệ thống của cơ quan hải quan và xác nhận Phiếu theo dõi trừ lùi các máy móc, thiết bị hoặc chi tiết, linh kiện chưa nhập khẩu.

b) Kiểm tra khi làm thủ tục nhập khẩu

b.1) Ngoài thủ tục hải quan theo quy định, cơ quan hải quan nơi làm thủ tục nhập khẩu căn cứ hồ sơ hải quan, kiểm tra, đối chiếu với Danh mục đã đăng ký, Phiếu theo dõi trừ lùi để thực hiện phân loại và trừ lùi những máy móc, thiết bị hoặc chi tiết, linh kiện đã thực tế nhập khẩu và xác nhận số lượng hàng hóa đã trừ lùi, lưu 01 bản chụp Danh mục và 01 bản chụp Phiếu theo dõi trừ lùi đã thực hiện trừ lùi vào hồ sơ hải quan.

b.2) Trường hợp người khai hải quan làm thủ tục nhập khẩu tại cơ quan hải quan khác với cơ quan hải quan nơi đăng ký Danh mục thì cơ quan hải quan nơi làm thủ tục nhập khẩu tiếp nhận 01 bản chính Danh mục kèm Phiếu theo dõi trừ lùi do người khai hải quan xuất trình, thực hiện theo hướng dẫn tại điểm b.1 khoản 3 Điều này.

b.3) Hết lượng hàng hoá nhập khẩu, cơ quan hải quan nơi làm thủ tục cho lô hàng cuối cùng xác nhận “đã nhập hết hàng hóa theo danh mục số….” lên Phiếu theo dõi trừ lùi, lưu 01 bản chính, chuyển cho người khai hải quan 01 bản chụp. Trường hợp cơ quan hải quan nơi làm thủ tục cho lô hàng cuối cùng không phải là nơi cấp Phiếu theo dõi trừ lùi thì lưu 01 bản chụp và gửi 01 bản chính đến cơ quan hải quan nơi cấp Phiếu theo dõi trừ lùi.

Cơ quan hải quan nơi cấp Phiếu theo dõi trừ lùi thực hiện kiểm tra đối với hàng hóa đã thông quan theo nguyên tắc quản lý rủi ro.

4. Cơ quan hải quan nơi đăng ký Danh mục và cấp Phiếu theo dõi trừ lùi tổ chức phân loại, xác định rủi ro đối với các Danh mục chưa nhập khẩu hết theo thời hạn đã đăng ký để thực hiện kiểm tra việc phân loại hàng hóa đã thông quan theo quy định.

5. Trường hợp khai bổ sung (nếu có) thực hiện theo quy định của Bộ Tài chính về thủ tục hải quan; kiểm tra, giám sát hải quan; thuế xuất khẩu, thuế nhập khẩu và quản lý thuế đối với hàng hóa xuất khẩu, nhập khẩu.

### Điều 10. Hồ sơ yêu cầu phân tích

Cơ quan hải quan nơi có yêu cầu phân tích hàng hóa có trách nhiệm lập và gửi hồ sơ yêu cầu phân tích đến cơ quan kiểm định hải quan, hồ sơ gồm:

1. Hồ sơ yêu cầu phân tích, phân loại hàng hoá:

a) Phiếu yêu cầu phân tích hàng hóa xuất khẩu, nhập khẩu kiêm Biên bản lấy mẫu hàng hóa (theo mẫu số 01/PYCPT/2026 Phụ lục ban hành kèm Thông tư này). Mỗi mặt hàng lập 01 Phiếu yêu cầu phân tích hàng hóa xuất khẩu, nhập khẩu kiêm Biên bản lấy mẫu hàng hóa.

b) Phiếu ghi số, ngày văn bản, chứng từ thuộc hồ sơ hải quan liên quan đến mẫu hàng hóa theo mẫu số 05/PGTL/2026 Phụ lục ban hành kèm theo Thông tư này (trong trường hợp khai tờ khai hải quan giấy).

c) Mẫu hàng hóa yêu cầu phân tích.

d) Tài liệu kỹ thuật của hàng hóa hoặc bản phân tích thành phần sản phẩm (đối với trường hợp không khai thác được trên hệ thống).

Trường hợp không có tài liệu kỹ thuật hoặc bản phân tích thành phần sản phẩm thì cơ quan hải quan nơi gửi hồ sơ phải nêu lý do tại mục 12 mẫu số 01/PYCPT/2026.

2. Hồ sơ yêu cầu kiểm tra, đánh giá tiêu chí kỹ thuật của hàng hóa

Thực hiện theo quy định tại điểm a khoản 5 Điều 29 Thông tư số 38/2015/TT-BTC quy định về thủ tục hải quan; kiểm tra, giám sát hải quan; thuế xuất khẩu, thuế nhập khẩu và quản lý thuế đối với hàng hoá xuất khẩu, nhập khẩu được sửa đổi, bổ sung bởi Thông tư số 39/2018/TT-BTC và Thông tư số 121/2025/TT-BTC.

### Điều 11. Mẫu hàng hóa yêu cầu phân tích

1. Người khai hải quan có trách nhiệm xuất trình hàng hóa để cơ quan hải quan lấy mẫu thực hiện phân tích.

2. Lấy mẫu hàng hóa.

a) Hàng hóa xuất khẩu, nhập khẩu phải lấy mẫu để phân tích theo quy định tại khoản 5 Điều 29 Nghị định số 08/2015/NĐ-CP được sửa đổi bổ sung bởi Nghị định số 167/2025/NĐ-CP. Khi lấy mẫu phải lập Phiếu yêu cầu phân tích hàng hóa xuất khẩu, nhập khẩu kiêm Biên bản lấy mẫu hàng hóa theo quy định tại Điều 10 nêu trên.

Mẫu được lấy từ chính lô hàng cần phân tích và mang tính đại diện; phải đủ về số lượng, khối lượng để phục vụ cho việc trưng cầu giám định hoặc giải quyết khiếu nại. Khi lấy mẫu phải có đại diện của người khai hải quan. Mẫu phải được các bên ký xác nhận và niêm phong riêng biệt từng mẫu. Khi bàn giao mẫu phải có biên bản bàn giao và ký xác nhận của các bên.

Trường hợp lấy mẫu nhưng vắng mặt người khai hải quan, cơ quan hải quan lấy mẫu với sự chứng kiến của đại diện ít nhất một trong các bên sau: Doanh nghiệp kinh doanh cảng, kho, bãi hoặc cơ quan nhà nước tại khu vực cửa khẩu hoặc đại diện doanh nghiệp vận tải và phải có ký xác nhận của các bên chứng kiến.

b) Số lượng mẫu: 02 mẫu.

Trường hợp người khai hải quan chỉ nhập khẩu 01 mẫu thì không thực hiện lấy mẫu.

c) Giao nhận mẫu: Cơ quan hải quan nơi yêu cầu phân tích gửi mẫu trực tiếp hoặc qua đường bưu điện đến cơ quan kiểm định hải quan.

Mẫu chỉ có giá trị pháp lý khi còn nguyên niêm phong.

3. Sử dụng mẫu hàng hóa.

a) Phân tích: Cơ quan kiểm định hải quan tiếp nhận mẫu (theo mẫu số 02/PTNYCPT/2026 Phụ lục ban hành kèm Thông tư này) và thực hiện phân tích;

b) Lưu mẫu: Trong thời hạn 120 ngày kể từ ngày ban hành Thông báo kết quả phân tích, phân loại; Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật, trừ những loại hàng hóa đặc biệt như hàng hóa dễ gây nguy hiểm, hàng hóa đã bị biến chất hoặc hàng hóa không thể lưu giữ được trong thời gian trên.

Trong thời hạn 120 ngày kể từ ngày ban hành Thông báo kết quả phân tích, phân loại, Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật, người khai hải quan không đồng ý với kết quả phân tích và đề nghị giám định tại các tổ chức có chức năng theo quy định của pháp luật hoặc khiếu nại liên quan đến kết quả phân tích, phân loại, cơ quan kiểm định hải quan lưu mẫu cho đến khi có quyết định giải quyết khiếu nại.

c) Trả lại mẫu hàng hóa.

Trường hợp người khai hải quan yêu cầu trả lại mẫu thì cơ quan kiểm định hải quan lập biên bản trả mẫu cho người khai hải quan (theo mẫu số 03/BBTLMHH/2026 Phụ lục ban hành kèm Thông tư này) và không chịu trách nhiệm về phẩm chất hàng hóa đối với những mẫu được trả lại do đã chịu tác động của quá trình phân tích mẫu. Trường hợp trả lại mẫu hàng hóa đang trong thời hạn lưu mẫu theo quy định tại điểm b khoản 3 Điều này, người khai hải quan đã công nhận kết quả phân tích thì không được khiếu nại về kết quả phân tích.

d) Hủy mẫu hàng hóa đã phân tích.

Cơ quan hải quan hủy mẫu đối với mẫu hết hạn lưu giữ theo quy định, mẫu hàng hóa dễ gây nguy hiểm, mẫu hàng hóa đã bị biến chất hoặc mẫu hàng hóa không còn khả năng lưu giữ. Biên bản hủy mẫu nêu rõ tình trạng của mẫu lưu, lý do hủy mẫu. Quyết định hủy mẫu và biên bản hủy mẫu được lưu theo quy định về lưu giữ hồ sơ.

4. Cục trưởng Cục Hải quan hướng dẫn cụ thể về quy trình kỹ thuật đối với việc lấy mẫu, hủy mẫu.

5. Trường hợp cơ quan hải quan gửi mẫu trưng cầu giám định, thử nghiệm tại các tổ chức giám định, thử nghiệm thì lập hồ sơ, thực hiện thủ tục gửi mẫu giám định, thử nghiệm theo quy định của pháp luật.

### Điều 12. Thông báo kết quả phân tích, phân loại và Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật

1. Đội trưởng Đội Kiểm định hải quan ban hành Thông báo kết quả phân tích, phân loại và Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật.

2. Chi cục trưởng Chi cục Kiểm định hải quan có trách nhiệm tổ chức thực hiện và đảm bảo sự thống nhất trong việc ban hành Thông báo kết quả phân tích, phân loại và Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật.

3. Trong thời hạn không quá 05 ngày làm việc, trường hợp thời gian phân tích phụ thuộc thời gian do yêu cầu quy trình kỹ thuật phân tích hoặc mẫu hàng hóa phức tạp thì không quá 20 ngày làm việc kể từ ngày tiếp nhận đủ hồ sơ và mẫu phân tích, Đội trưởng Đội Kiểm định hải quan ban hành Thông báo kết quả phân tích, phân loại (theo mẫu số 04/TBKQPTPL/2026 Phụ lục ban hành kèm theo Thông tư này) và Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật (theo mẫu số 43-KQKTĐG/KĐHQ Phụ lục I ban hành kèm theo Thông tư số 121/2025/TT-BTC).

Trường hợp mặt hàng phức tạp, khó phân loại, cơ quan hải quan cần xin ý kiến Bộ, cơ quan ngang Bộ quản lý chuyên ngành hoặc Ủy ban HS thuộc Tổ chức Hải quan thế giới hoặc Nhóm kỹ thuật về phân loại hàng hoá của ASEAN hoặc phải thực hiện xác minh tại cơ sở sản xuất theo quy định tại khoản 5a Điều 29 Thông tư số 38/2015/TT-BTC được sửa đổi, bổ sung bởi Thông tư số 39/2018/TT-BTC và Thông tư số 121/2025/TT-BTC thì không quá 05 ngày làm việc kể từ ngày nhận được văn bản trả lời hoặc kết quả xác minh tại cơ sở sản xuất, cơ quan kiểm định hải quan ban hành Thông báo kết quả phân tích, phân loại.

4. Trường hợp cơ quan kiểm định hải quan gửi mẫu trưng cầu giám định, thử nghiệm tại các tổ chức giám định, thử nghiệm thì trong thời hạn không quá 05 ngày làm việc, trường hợp mẫu hàng hóa phức tạp cần có thêm thời gian thì không quá 08 ngày làm việc kể từ ngày nhận được kết quả giám định, thử nghiệm hàng hóa, Đội trưởng Đội Kiểm định hải quan ban hành Thông báo kết quả phân tích, phân loại.

5. Việc ban hành và sử dụng Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật thực hiện theo quy định tại điểm a khoản 5 Điều 29 Thông tư số 38/2015/TT-BTC được sửa đổi, bổ sung bởi Thông tư số 39/2018/TT-BTC và Thông tư số 121/2025/TT-BTC.

6. Thông báo kết quả phân tích, phân loại; Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật là cơ sở để xác định mức thuế, thực hiện chính sách quản lý hàng hóa; được cập nhật vào cơ sở dữ liệu của cơ quan hải quan. Thông báo kết quả phân tích, phân loại được công khai trên trang thông tin điện tử của Cục Hải quan (trừ phần phụ lục của Thông báo kết quả phân tích, phân loại).

7. Trường hợp người khai hải quan không đồng ý với Thông báo kết quả phân tích, phân loại thì thực hiện khiếu nại theo Luật Khiếu nại số 02/2011/QH13 hoặc trưng cầu giám định theo quy định tại Điều 30 Nghị định số 08/2015/NĐ-CP.

### Điều 13. Nguồn thông tin xây dựng Cơ sở dữ liệu về Danh mục hàng hóa xuất khẩu, nhập khẩu

1. Công ước HS và các phụ lục kèm theo;

2. Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam;

3. Danh mục hàng hóa cấm xuất khẩu, cấm nhập khẩu, Danh mục hàng hóa xuất khẩu, nhập khẩu theo giấy phép, theo điều kiện, Danh mục hàng hóa xuất khẩu, nhập khẩu thuộc diện quản lý chuyên ngành theo quy định tại Nghị định số 69/2018/NĐ-CP quy định chi tiết một số Điều của Luật Quản lý ngoại thương;

4. Văn bản hướng dẫn về phân loại hàng hóa của Bộ Tài chính, Cục Hải quan;

5. Thông báo kết quả xác định trước mã số; Thông báo kết quả phân tích, phân loại hàng hoá; Thông báo kết quả phân tích kèm mã số hàng hóa; Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật;

6. Các văn bản giải quyết khiếu nại về phân loại hàng hóa, áp dụng mức thuế của Bộ Tài chính, Cục Hải quan.

### Điều 14. Thẩm quyền thu thập, cập nhật, sửa đổi Cơ sở dữ liệu về Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam

1. Cục Hải quan tổ chức thu thập, cập nhật, sửa đổi cơ sở dữ liệu về Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam theo quy định tại Điều 18 Nghị định số 08/2015/NĐ-CP đảm bảo tính đầy đủ, toàn diện, tập trung, thống nhất và cập nhật kịp thời, đảm bảo an toàn thông tin và có khả năng kết nối, chia sẻ, đồng bộ dữ liệu với các cơ sở dữ liệu Quốc gia theo quy định.

2. Thông tin trong cơ sở dữ liệu được bổ sung, sửa đổi khi các nguồn thông tin nêu tại Điều 13 Thông tư này thay đổi.

3. Cục Hải quan công khai các thông tin nêu tại Điều 13 Thông tư này trên trang thông tin điện tử của Cục Hải quan để người khai hải quan, các cơ quan quản lý nhà nước có liên quan, cơ quan hải quan các cấp, công chức hải quan sử dụng và đồng bộ các danh mục nêu tại Điều 13 Thông tư này về danh mục điện tử dùng chung ngành Tài chính để các đơn vị trong ngành Tài chính, người khai hải quan, các cơ quan quản lý nhà nước có liên quan, cơ quan hải quan các cấp, công chức hải quan sử dụng.

### Điều 15. Hiệu lực thi hành

1. Thông tư này có hiệu lực thi hành kể từ ngày 15 tháng 09 năm 2026.

Thông tư này thay thế Thông tư số 14/2015/TT-BTC ngày 30 tháng 01 năm 2015 của Bộ Tài chính hướng dẫn về phân loại hàng hoá, phân tích để phân loại hàng hoá; phân tích để kiểm tra chất lượng, kiểm tra an toàn thực phẩm đối với hàng hoá xuất khẩu, nhập khẩu và Thông tư số 17/2021/TT-BTC ngày 26 tháng 02 năm 2021 của Bộ Tài chính sửa đổi, bổ sung một số Điều tại Thông tư số 14/2015/TT-BTC.

2. Trường hợp các văn bản quy phạm pháp luật viện dẫn tại Thông tư này được sửa đổi, bổ sung hoặc thay thế bằng văn bản quy phạm pháp luật khác thì áp dụng theo quy định tại văn bản sửa đổi, bổ sung hoặc thay thế đó.

### Điều 16. Điều khoản chuyển tiếp

1. Trường hợp hàng hóa thuộc tờ khai hải quan đăng ký đã được lấy mẫu hàng hóa để phân tích, giám định, thử nghiệm nhưng đến ngày Thông tư này có hiệu lực thi hành chưa có kết quả thì thực hiện theo quy định của văn bản liên quan có hiệu lực tại thời điểm đăng ký tờ khai.

Việc thực hiện phân loại hàng hóa, lấy mẫu, gửi mẫu, lưu mẫu phân tích, thực hiện phân tích, phân loại, giám định, thử nghiệm tiếp tục thực hiện theo pháp luật áp dụng tại thời điểm trước khi Thông tư này có hiệu lực.

2. Trường hợp nhập khẩu máy liên hợp hoặc tổ hợp máy thuộc các Chương 84, Chương 85 và Chương 90 và chi tiết, linh kiện rời theo Danh mục đã đăng ký trước thời điểm có hiệu lực của Thông tư này thì vẫn tiếp tục thực hiện theo quy định tại Thông tư số 14/2015/TT-BTC cho đến khi nhập hết hàng hóa theo Danh mục.

### Điều 17. Tổ chức thực hiện

1. Cục trưởng Cục Hải quan căn cứ vào Thông tư này ban hành Quy trình phân loại hàng hoá, áp dụng mức thuế đối với hàng hoá xuất khẩu, nhập khẩu; Quy trình phân tích phân loại và kiểm tra, đánh giá tiêu chí kỹ thuật của hàng hoá xuất khẩu, nhập khẩu; Quy chế xây dựng, thu thập, cập nhật Cơ sở dữ liệu; xây dựng và đảm bảo cơ sở vật chất, thiết bị máy móc, nguồn nhân lực để thực hiện hiệu quả nhiệm vụ phân tích hàng hóa xuất khẩu, nhập khẩu; hướng dẫn các đơn vị hải quan thực hiện thống nhất, bảo đảm tạo điều kiện thuận lợi cho hoạt động xuất khẩu, nhập khẩu, thực hiện tốt công tác quản lý nhà nước về hải quan;

2. Cơ quan hải quan, người khai hải quan, người nộp thuế và các tổ chức, cá nhân có liên quan có trách nhiệm thực hiện việc phân loại hàng hóa, phân tích để phân loại hàng hóa, cơ sở dữ liệu về Danh mục hàng hoá xuất khẩu, nhập khẩu Việt Nam, ứng dụng công nghệ thông tin trong quản lý theo đúng quy định hiện hành và hướng dẫn tại Thông tư này. Quá trình thực hiện có phát sinh vướng mắc, cơ quan hải quan, người khai hải quan, người nộp thuế và các tổ chức, cá nhân có liên quan báo cáo, phản ánh về Bộ Tài chính (Cục Hải quan) để được xem xét, hướng dẫn giải quyết kịp thời.


## 3. Danh mục nguồn CSDL theo Điều 13

- **1.** Công ước HS và các phụ lục kèm theo
- **2.** Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam
- **3.** Danh mục hàng hóa cấm xuất khẩu, cấm nhập khẩu, Danh mục hàng hóa xuất khẩu, nhập khẩu theo giấy phép, theo điều kiện, Danh mục hàng hóa xuất khẩu, nhập khẩu thuộc diện quản lý chuyên ngành theo quy định tại Nghị định số 69/2018/NĐ-CP quy định chi tiết một số Điều của Luật Quản lý ngoại thương
- **4.** Văn bản hướng dẫn về phân loại hàng hóa của Bộ Tài chính, Cục Hải quan
- **5.** Thông báo kết quả xác định trước mã số; Thông báo kết quả phân tích, phân loại hàng hoá; Thông báo kết quả phân tích kèm mã số hàng hóa; Thông báo kết quả kiểm tra, đánh giá tiêu chí kỹ thuật
- **6.** Các văn bản giải quyết khiếu nại về phân loại hàng hóa, áp dụng mức thuế của Bộ Tài chính, Cục Hải quan

## 4. Mapping TT85 vào hệ thống AI

- **Legal Scope Router** — Nguồn: Điều 1, Điều 2. Xác định phạm vi áp dụng và thuật ngữ chuẩn.
- **Classification Agent** — Nguồn: Điều 4, Điều 6. Áp dụng căn cứ phân loại và fallback evidence.
- **GIR/Graph Engine** — Nguồn: Điều 4 khoản 2 điểm d, Điều 8. Bắt buộc dùng 6 GIR; Điều 8 kích hoạt GIR 2(a) cho hàng tháo rời/chưa lắp ráp.
- **Combined Machine Handler** — Nguồn: Điều 7, Điều 9. Xử lý máy liên hợp/tổ hợp Chương 84/85/90 và hồ sơ nhiều chuyến.
- **Spec Completeness / HITL** — Nguồn: Điều 3, Điều 10, Điều 11. Phát hiện thiếu dữ liệu kỹ thuật, yêu cầu bổ sung/giám định/phân tích.
- **Critic Agent** — Nguồn: Điều 6, Điều 12. Kiểm tra nguồn hỗ trợ, tiêu chí kỹ thuật và kết quả phân tích/phân loại.
- **Case-Based RAG** — Nguồn: Điều 12 khoản 6, Điều 13 khoản 5, Điều 13 khoản 6. Dùng thông báo/giải quyết khiếu nại làm case evidence.
- **Knowledge Base Updater** — Nguồn: Điều 13, Điều 14. Quản lý nguồn chính thức và cập nhật khi nguồn thay đổi.
- **Effective-Date Validator** — Nguồn: Điều 15, Điều 16. Đảm bảo đúng phiên bản pháp luật và quy định chuyển tiếp.
- **Tax / Trade Policy Service** — Nguồn: Điều 5, Điều 12 khoản 6. Dùng mã đã phân loại để áp chính sách quản lý và mức thuế.

## 5. Phụ lục — toàn bộ nội dung biểu mẫu

Phụ lục

DANH MỤC MẪU BIỂU(Kèm theo Thông tư số 85/2026/TT-BTC ngày 30 tháng 6 năm 2026 của Bộ trưởng Bộ Tài chính)

| Mẫu số | Tên Biểu mẫu | Ký hiệu |
| --- | --- | --- |
| 01 | Phiếu yêu cầu phân tích hàng hóa xuất khẩu, nhập khẩu kiêm Biên bản lấy mẫu | 01/PYCPT/2026 |
| 02 | Phiếu tiếp nhận yêu cầu phân tích hàng hóa xuất khẩu, nhập khẩu | 02/PTNYCPT/2026 |
| 03 | Biên bản trả lại mẫu đã tiếp nhận yêu cầu phân tích | 03/BBTLMHH/2026 |
| 04 | Thông báo về kết quả phân tích, phân loại đối với hàng hóa xuất khẩu, nhập khẩu | 04/TBKQPTPL/2026 |
| 05 | Phiếu ghi số, ngày văn bản, chứng từ thuộc hồ sơ hải quan liên quan đến mẫu hàng hoá | 05/PGTL/2026 |

Mẫu số 01/PYCPT/2026

| CHI CỤC HẢI QUAN KHU VỰC …ĐƠN VỊ YÊU CẦU PHÂN TÍCH | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAMĐộc lập - Tự do - Hạnh phúc |
| --- | --- |
| Số: …………… | …….., ngày … tháng … năm ….. |

PHIẾU YÊU CẦU PHÂN TÍCH HÀNG HÓA XUẤT KHẨU,NHẬP KHẨU KIÊM BIÊN BẢN LẤY MẪU

Kính gửi:…………………………………

1. Tên hàng theo khai báo: ....................................................................................

2. Mã số hàng hóa theo khai báo: ...........................................................................

3. Số tờ khai hải quan: …………… ngày …………. tháng ……… năm ..........

4. Số giấy chứng nhận xuất xứ (C/O) (nếu có)...... ngày...... tháng …... năm .......

5. Đơn vị XK, NK, ................................................................................................

6. Ngày lấy mẫu: ………………… Địa điểm lấy mẫu: ......................................

7. Người lấy mẫu:

- Công chức hải quan 1: ........................................................................................

- Công chức hải quan 2: .........................................................................................

- Đại diện người khai hải quan: ..............................................................................

8. Đặc điểm và quy cách đóng gói mẫu: ................................................................

9. Số lượng mẫu/Chi tiết mẫu (kích thước, đặc điểm): ..........................................

10. Hình thức kiểm tra thực tế hàng hóa (miễn kiểm tra hoặc kiểm tra tỷ lệ hoặc kiểm tra toàn bộ) …………………………………………………………………

11. Mẫu đã được niêm phong hải quan số: ............................................................

12. Hồ sơ kèm theo:

(1) Hợp đồng thương mại (bản chụp):                           Có □            Không □

(2) Tài liệu kỹ thuật có liên quan (bản chụp):                Có □            Không □

(3) Chứng thư giám định (bản chụp, nếu có):                Có □            Không □

(4) Phiếu ghi kết quả kiểm tra thực tế hàng hoá       Có □            Không □

(mẫu số 06/PGKQKT/GSQL)

(5) Giấy tờ khác có liên quan (nếu có, ghi rõ loại giấy tờ):...........................................................................................................................

13. Nội dung yêu cầu phân tích: (ghi rõ cơ sở nghi ngờ, nội dung nghi ngờ, mã số nghi ngờ, tiêu chí yêu cầu phân tích, phân loại cụ thể theo Chú giải HS, Chú giải bổ sung Danh mục AHTN, Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam, Biểu thuế xuất khẩu, nhập khẩu, ghi chỉ đạo của Cục Hải quan (ghi rõ số, ngày văn bản/chỉ đạo - nếu có) và chỉ thị rủi ro đối với mặt hàng yêu cầu phân tích, phân loại (nếu có).).........................................................................................

14. Người khai hải quan yêu cầu lấy lại mẫu:                 Có □            Không □

Tên người được ủy quyền nhận lại mẫu: ................................................................

Phiếu yêu cầu này được lập thành 02 bản, 01 bản lưu cùng hồ sơ lưu của Hải quan, 01 bản gửi trong hồ sơ phân tích.

| ĐẠI DIỆN NGƯỜI KHAI HẢI QUAN (15)(Ký, ghi rõ họ, tên) | CÔNG CHỨC HẢI QUAN(Ký, ghi rõ họ, tên, và đóng dấu công chức) | THỦ TRƯỞNG ĐƠN VỊ YÊU CẦU PHÂN TÍCH(Ký, ghi rõ họ, tên, đóng dấu) |
| --- | --- | --- |
|  |  |  |

Ghi chú: (15) Trường hợp vắng mặt người khai hải quan khi lấy mẫu thì phải có chữ ký của người chứng kiến là đại diện doanh nghiệp kinh doanh cảng, kho, bãi hoặc cơ quan nhà nước tại khu vực cửa khẩu hoặc doanh nghiệp vận tải.

Mẫu số 02/PTNYCPT/2026

| CHI CỤC KIỂM ĐỊNH HẢI QUAN ĐỘI KIỂM ĐỊNH HẢI QUAN… | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAMĐộc lập - Tự do - Hạnh phúc |
| --- | --- |
| Số: ………./PTPL-NV | …., ngày….. tháng … năm….. |

PHIẾU TIẾP NHẬN YÊU CẦU PHÂN TÍCH HÀNG HÓA

XUẤT KHẨU, NHẬP KHẨU

- Thời gian tiếp nhận yêu cầu phân tích: ngày ……….. tháng .... năm ..................

- Phiếu yêu cầu phân tích kiêm biên bản lấy mẫu số: ………… ngày ...................

- Đơn vị yêu cầu phân tích: ....................................................................................

- Tên mẫu theo khai báo: ........................................................................................

- Số tờ khai hải quan: ………………… ngày ……….. tháng ………. năm .........

- Số giấy chứng nhận xuất xứ (C/O):.... ngày ...... tháng...... năm ..........................

- Đơn vị XK, NK/Tổ chức, cá nhân: ......................................................................

- Số lượng mẫu: ......................................................................................................

- Phân công thực hiện phân tích và lưu ý: ..............................................................

| NGƯỜI GIAO(Ký và ghi rõ họ tên) | THỦ TRƯỞNG ĐƠN VỊ KIỂM ĐỊNH HẢI QUAN(Ký, ghi rõ họ tên, và đóng dấu)NGƯỜI NHẬN(Ký và ghi rõ họ tên) |  |
| --- | --- | --- |

Ghi chú:Trường hợp Phiếu yêu cầu phân tích hàng hóa đề nghị xác định trước mã số, không yêu cầu điền các thông tin tờ khai hải quan

Mẫu số 03/BBTLMHH/2026

| CHI CỤC KIỂM ĐỊNH HẢI QUAN  ĐỘI KIỂM ĐỊNH HẢI QUAN …. | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAMĐộc lập - Tự do - Hạnh phúc |
| --- | --- |
| Số: ………./PTPL-NV | …., ngày … tháng … năm….. |

BIÊN BẢN TRẢ LẠI MẪU ĐÃ TIẾP NHẬN YÊU CẦU PHÂN TÍCH

Đội Kiểm định hải quan …..quyết định trả lại mẫu đã tiếp nhận yêu cầu phân tích như sau:

- Thời gian trả lại mẫu: ……….. giờ …….. ngày …..…. tháng ….…. năm .........

- Tên mẫu trả lại (theo khai báo): ...........................................................................

- Số tờ khai hải quan: …………………. Thông báo kết quả phân tích số: ...........

- Số lượng mẫu trả lại: ............................................................................................

- Đơn vị đề nghị trả lại mẫu:....................................................................................

- Công văn đề nghị trả lại mẫu số: ……………… Ngày.... tháng.... năm .............

- Người nhận lại mẫu (họ tên, thông tin  CCCD hoặc hộ chiếu, tên doanh nghiệp, cơ quan xin nhận lại mẫu): ........................................................................

- Giấy ủy quyền nhận lại mẫu (nếu có): ………. Ngày.... tháng.... năm ................

- Người trả lại mẫu: ................................................................................................

- Lưu ý: ...................................................................................................................

Chủ hàng cam đoan đã nhận lại mẫu và không khiếu nại về kết quả phân tích đối với mẫu hàng này sau khi đã được nhận lại mẫu.

| NGƯỜI NHẬN LẠI MẪU(Ký, ghi rõ họ, tên) | NGƯỜI TRẢ LẠI MẪU(Ký, ghi rõ họ, tên) | THỦ TRƯỞNG ĐƠN VỊ KIỂM ĐỊNH HẢI QUAN…(Ký, ghi rõ họ, tên và đóng dấu) |
| --- | --- | --- |

Ghi chú:

- Công văn đề nghị trả lại mẫu ghi rõ tên người nhận lại mẫu, thông tin CCCD hoặc hộ chiếu và nội dung cam đoan nêu trên;

- Giấy ủy quyền nhận lại mẫu áp dụng cho đại lý hải quan hoặc trường hợp chủ hàng quyết định ủy quyền cho một đại diện hợp pháp để nhận lại mẫu.

Mẫu số 04/TBKQPTPL/2026

| CHI CỤC KIỂM ĐỊNH HẢI QUANĐỘI KIỂM ĐỊNH HẢI QUAN…. | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAMĐộc lập - Tự do - Hạnh phúc |
| --- | --- |
| Số:       /TBKQPTPL-Đ… | …., ngày …  tháng … năm….. |

THÔNG BÁO

Về kết quả phân tích, phân loại đối với hàng hóa xuất khẩu, nhập khẩu

Căn cứ Luật Hải quan số 54/2014/QH13 ngày 23/6/2014;

Căn cứ Nghị định số 08/2015/NĐ-CP ngày 21/01/2015 của Chính phủ quy định chi tiết và biện pháp thi hành Luật Hải quan về thủ tục hải quan, kiểm tra giám sát, kiểm soát hải quan, được sửa đổi, bổ sung tại Nghị định số 167/2025/NĐ-CP ngày 30/6/2025 của Chính phủ;

Căn cứ Thông tư số ……./2026/TT-BTC ngày …../…../2026 của Bộ trưởng Bộ Tài chính quy định về phân loại hàng hóa, phân tích để phân loại hàng hóa;

Căn cứ Thông tư số …………. ngày ………………. của Bộ trưởng Bộ Tài chính về việc ban hành Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam;

Đội Kiểm định hải quan…. thông báo kết quả phân tích, phân loại hàng hóa như sau:

| 1. Tên hàng theo khai báo: ……………………………………………………… |
| --- |
| 2. Hình ảnh hàng hóa (nếu có) |
| 3. Tóm tắt mô tả và đặc tính hàng hóa: Kết quả phân tích hàng hoá và các thông tin khác về thuộc tính của hàng hoá (như công dụng, quy trình sản xuất,… nếu ảnh hưởng đến việc xác định bản chất hàng hóa):………………………………………………………… |
| 4. Kết quả phân loại: Mô tả hàng hóa theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam (nêu rõ các thuộc tính khác như công dụng, quy trình sản xuất,… nếu ảnh hưởng đến việc phân loại):…………………………… Mã số phân loại hàng hoá theo Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam:thuộc nhóm..., phân nhóm..., mã số …………………… tại Danh mục hàng hóa xuất khẩu, nhập khẩu Việt Nam./. |

Thông báo này có hiệu lực kể từ ngày ban hành./.

| Nơi nhận:- LĐ Chi Cục KĐHQ (để báo cáo); - Các Chi cục HQKV (để t/hiện);- Đơn vị yêu cầu phân tích (để t/hiện); - Tên đơn vị XK, NK; - Ban Nghiệp vụ thuế hải quan;- Website Hải quan;- Lưu: VT, ………. (đơn vị XL)-(CV xử lý hồ sơ) (3b). | THỦ TRƯỞNG ĐƠN VỊ KIỂM ĐỊNH HẢI QUAN……(Ký, ghi rõ họ, tên, và đóng dấu) |
| --- | --- |

Ghi chú: Thông báo kết quả này có giá trị đối với mẫu yêu cầu phân tích

* Trên cơ sở kết quả giám định, thử nghiệm số …. của đơn vị giám định, thử nghiệm (nếu mẫu được gửi đi giám định, thử nghiệm).

Phụ lục thông báo

(Kèm theo Thông báo số …../TBKQPTPL-Đ…ngày …tháng…năm ...của Đội Kiểm định hải quan…)

1. Đơn vị xuất khẩu/nhập khẩu: ……………

Địa chỉ: …………………………

Mã số thuế: ……………………………

2. Số, ngày tờ khai hải quan …………………………… tại Hải quan cửa khẩu/ngoài cửa khẩu ………….. (Chi cục Hải quan …………………..)

3. Ký hiệu sản phẩm (nếu có): …………

4. Quy trình sản xuất (nếu có): ………..

Mẫu số 05/PGTL/2026

CHI CỤC HẢI QUAN KHU VỰC ……

TÊN ĐƠN VỊ YÊU CẦU PHÂN TÍCH

PHIẾU GHI SỐ, NGÀY VĂN BẢN, CHỨNG TỪ THUỘC HỒ SƠ HẢI QUAN LIÊN QUAN ĐẾN MẪU HÀNG HOÁ

| STT | Tên tài liệu | Đơn vị yêu cầuphân tích |
| --- | --- | --- |
| (1) | (2) | (3) |
| 1 | Phiếu yêu cầu phân tích kiêm biên bản lấy mẫu/Phiếu yêu cầu kiểm tra, đánh giá tiêu chí kỹ thuật hàng hoá xuất khẩu, nhập khẩu bằng máy móc, thiết bị tại cơ quan kiểm định hải quan kiêm Biên bản lấy mẫu hàng hóa | ◻ |
| 2 | Phiếu ghi kết quả kiểm tra thực tế hàng hóa (mẫu số 06/PGKQKT/GSQL) (Trường hợp thực hiện kiểm tra thực tế hàng hoá) | ◻ |
| 3 | Các tài liệu liên quan khác (nếu có: Ghi cụ thể tên các tài liệu ):…………………………..…………………………. | ◻ |
| 4 | Tổng số tờ tài liệu: |  |

| …., ngày… tháng…năm ….Công chức bàn giao hồ sơ yêu cầu phân tích (Ký, ghi rõ họ tên) | …., ngày… tháng…năm …. Công chức nhận hồ sơ tại Đội Kiểm định hải quan…(Ký, ghi rõ họ tên) |
| --- | --- |

Ghi chú: Đánh dấu “X” vào ô nếu có tài liệu đính kèm hồ sơ
